# ristek-mercurial
Main Website Ristek 2017

Features:
- Landing page - on progress, high priority
- Blog (Wordpress & REST API) - low priority
